<footer class="footer mt-auto py-3 bg-white text-center">
    <div class="container">
        <span class="text-muted">
            {!! settings('footer_text') !!}
        </span>
    </div>
</footer>
