<img
    src="{{ asset('assets/images/note_taking.svg') }}"
    alt=""
    class="w-35"
/>
<h5 class="mt-3 tx-18">{{ __('Its Empty In Here') }}</h5>
