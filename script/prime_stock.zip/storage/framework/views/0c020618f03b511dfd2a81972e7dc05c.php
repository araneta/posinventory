<?php $__env->startSection('title', __('Email Template')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Email Template')); ?></h5>
        </div>
    </div>
    <!-- Page Header Close -->

    <div class="card custom-card <?php echo e($emailTemplates->count() <= 0 ? 'text-center' : ''); ?>">
        <div class="card-header justify-content-between">
            <?php echo $__env->make('includes.__table_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-body">
            <?php if($emailTemplates->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table text-nowrap">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo e(__('Name')); ?></th>
                            <th scope="col"><?php echo e(__('Subject')); ?></th>
                            <th scope="col"><?php echo e(__('Type')); ?></th>
                            <th scope="col"><?php echo e(__('Action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $emailTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($template->name); ?></strong>
                                </td>
                                <td>
                                    <?php echo e($template->subject); ?>

                                </td>
                                <td>
                                    <?php echo e(ucwords($template->type)); ?>

                                </td>
                                <td>
                                    <div class="hstack gap-2 flex-wrap">
                                        <a
                                            href="<?php echo e(route('email-template.edit', $template)); ?>"
                                            class="btn btn-primary btn-icon rounded-pill btn-wave btn-sm"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(__('Edit')); ?>"
                                        ><i class="ri-edit-line"></i
                                            ></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($emailTemplates->links('includes.__pagination')); ?>

            <?php else: ?>
                <?php echo $__env->make('includes.__empty_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/email-template/index.blade.php ENDPATH**/ ?>