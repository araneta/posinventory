<?php $__env->startSection('title', __('Brand')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-3">
        <div class="col-md-4">
            <div class="card custom-card collapse-card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <div class="card-title mb-0" id="title">
                        <?php echo e(__('Add Brand')); ?>

                    </div>
                    <div>
                        <a href="<?php echo e(route('brand.index')); ?>" class="mx-2"><i class="ri-refresh-line fs-18"></i></a>
                        <a href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseExample"
                            aria-expanded="false" aria-controls="collapseExample">
                            <i class="ri-arrow-down-s-line fs-18 collapse-open"></i>
                            <i class="ri-arrow-up-s-line collapse-close fs-18"></i>
                        </a>
                    </div>
                </div>
                <div class="collapse show" id="collapseExample">
                    <form action="<?php echo e(route('brand.store')); ?>" method="POST" id="brandForm">
                        <?php echo csrf_field(); ?>
                        <div id="method_sec">
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="name" class="form-label fs-14 text-dark"><?php echo e(__('Brand Name')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name"
                                    placeholder="Enter brand name">
                            </div>
                            <div class="mb-3">
                                <label for="form-password"
                                    class="form-label fs-14 text-dark me-2"><?php echo e(__('Status')); ?></label>
                                <input type="radio" class="btn-check" value="1" name="status"
                                    id="success-outlined" />
                                <label class="btn btn-outline-success m-1"
                                    for="success-outlined"><?php echo e(__('Active')); ?></label>
                                <input type="radio" class="btn-check" value="0" name="status" id="danger-outlined"
                                    checked />
                                <label class="btn btn-outline-danger m-1" for="danger-outlined"><?php echo e(__('Deactive')); ?></label>
                            </div>
                        </div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-brand')): ?>
                            <div class="card-footer">
                                <button class="btn btn-primary" type="submit"><?php echo e(__('Save Changes')); ?></button>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card custom-card <?php echo e($brands->count() <= 0 ? 'text-center' : ''); ?>">
                <div class="card-header justify-content-between">
                    <?php echo $__env->make('includes.__table_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body">
                    <?php if($brands->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table text-nowrap">
                                <thead>
                                    <tr>
                                        <th scope="col"><?php echo e(__('Brand Name')); ?></th>
                                        <th scope="col"><?php echo e(__('Status')); ?></th>
                                        <th scope="col"><?php echo e(__('Product')); ?></th>
                                        <th scope="col"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($brand->name); ?></td>
                                            <td>
                                                <?php if($brand->status): ?>
                                                    <span
                                                        class="badge rounded-pill bg-success-gradient p-2"><?php echo e(__('Active')); ?></span>
                                                <?php else: ?>
                                                    <span
                                                        class="badge rounded-pill bg-danger-gradient p-2"><?php echo e(__('Deactivate')); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-dark"><?php echo e($brand->products->count()); ?></span>
                                            </td>
                                            <td>
                                                <div class="hstack gap-2 flex-wrap">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-brand')): ?>
                                                        <a href="javascript:void(0);" data-id="<?php echo e($brand->id); ?>"
                                                            data-name="<?php echo e($brand->name); ?>" data-status="<?php echo e($brand->status); ?>"
                                                            class="btn btn-primary btn-icon rounded-pill btn-wave btn-sm editBtn"
                                                            data-bs-toggle="tooltip" data-bs-placement="top"
                                                            title="<?php echo e(__('Edit')); ?>"><i class="ri-edit-line"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-brand')): ?>
                                                        <button data-id="<?php echo e($brand->id); ?>"
                                                            class="btn btn-danger btn-icon rounded-pill btn-wave btn-sm dltBtn"
                                                            data-bs-toggle="tooltip" data-bs-placement="top"
                                                            title="<?php echo e(__('Delete')); ?>"
                                                            <?php echo e($brand->products->count() > 0 ? 'disabled' : ''); ?>><i
                                                                class="ri-delete-bin-5-line"></i></button>
                                                    <?php endif; ?>
                                                    <form action="" id="dltForm" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo e($brands->links('includes.__pagination')); ?>

                    <?php else: ?>
                        <?php echo $__env->make('includes.__empty_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(function() {
            "use strict"
            var options = {
                'position': 'top-right'
            }
            var notifier = new AWN(options);
            //Edit Event
            $(document).on('click', '.editBtn', function() {
                let id = $(this).data('id');
                let name = $(this).data('name');
                let status = $(this).data('status');
                $("#title").html('<?php echo e(__('Edit Brand')); ?>')
                $("#name").val(name)
                status === 1 ? $('#success-outlined').attr('checked', 'checked') : $('#danger-outlined')
                    .attr('checked', 'checked');

                var url = '<?php echo e(route('brand.update', ':id')); ?>';
                url = url.replace(':id', id);
                $('#brandForm').attr('action', url);
                $('#method_sec').html('<input type="hidden" name="_method" value="PUT">')
            })


            //Delete Event
            $(document).on('click', '.dltBtn', function() {
                let onOk = () => {
                    var id = $(this).data('id');
                    var url = '<?php echo e(route('brand.destroy', ':id')); ?>';
                    url = url.replace(':id', id);
                    $('#dltForm').attr('action', url);
                    $('#dltForm').submit();
                };
                let onCancel = () => {
                    notifier.info('Your Item is safe')
                };
                notifier.confirm('<?php echo e(__('Are you sure you want to delete the items')); ?>', onOk, onCancel)
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/brand/index.blade.php ENDPATH**/ ?>