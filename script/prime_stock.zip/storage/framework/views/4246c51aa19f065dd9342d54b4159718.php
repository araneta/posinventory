<?php $__env->startSection('title', __('Purchase')); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Purchase')); ?></h5>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-purchase')): ?>
            <div class="d-flex my-xl-auto right-content align-items-center">
                <div class="pe-1 mb-xl-0">
                    <a href="<?php echo e(route('purchase.create')); ?>" class="btn btn-primary label-btn">
                        <i class="ri-add-circle-line label-btn-icon me-2"></i><?php echo e(__('Add New')); ?>

                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <!-- Page Header Close -->
    <?php echo $__env->make('purchase.include.__filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card custom-card <?php echo e($purchases->count() <= 0 ? 'text-center' : ''); ?>">
        <div class="card-header justify-content-between">
            <?php echo $__env->make('includes.__table_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-body">
            <?php if($purchases->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table text-nowrap">
                        <thead>
                            <tr class="text-center">
                                <th scope="col"><?php echo e(__('Invoice No|Date')); ?></th>
                                <th scope="col"><?php echo e(__('Supplier|Mobile')); ?></th>
                                <th scope="col"><?php echo e(__('Total Amount|Warehouse')); ?></th>
                                <th scope="col"><?php echo e(__('Discount|Tax|Payable')); ?></th>
                                <th scope="col"><?php echo e(__('Paid|Due')); ?></th>
                                <th scope="col"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td>
                                        <strong><?php echo e($purchase->invoice_no); ?></strong><br>
                                        <span><?php echo e($purchase->date); ?></span>
                                    </td>
                                    <td>
                                        <strong><?php echo e($purchase->supplier->name); ?></strong><br><span><?php echo e($purchase->supplier->phone); ?></span>
                                    </td>
                                    <td>
                                        <?php echo e(showAmount($purchase->total_price)); ?><br>
                                        <span class="text-primary"><?php echo e($purchase->warehouse->name); ?></span>
                                    </td>
                                    <td>
                                        <?php echo e(showAmount($purchase->discount)); ?> <br>
                                        <?php echo e(showAmount(taxAmount($purchase->total_price, $purchase->tax_amount))); ?> <br>
                                        <?php echo e(showAmount($purchase->payable_amount)); ?>

                                    </td>
                                    <td>
                                        <strong><?php echo e(showAmount($purchase->paying_amount)); ?></strong><br>
                                        <span
                                            class="badge bg-danger-transparent"><?php echo e(showAmount($purchase->payable_amount - $purchase->paying_amount)); ?></span>
                                    </td>

                                    <td>
                                        <div class="hstack gap-2 fs-15">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice-purchase')): ?>
                                                <a href="<?php echo e(route('purchase.show', $purchase->id)); ?>"
                                                    class="btn btn-icon btn-sm btn-success" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="<?php echo e(__('Invoice')); ?>"><i
                                                        class="ri-download-2-line"></i></a>
                                            <?php endif; ?>
                                            <?php if($purchase->status == 'due'): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('give-supplier-payment')): ?>
                                                    <a href="javascript:void(0);"
                                                        class="btn btn-icon btn-sm btn-dark givePayment"
                                                        data-bs-target="#paymentModal" data-bs-toggle="modal"
                                                        data-id="<?php echo e($purchase->id); ?>"
                                                        data-invoice="<?php echo e($purchase->invoice_no); ?>"
                                                        data-amount="<?php echo e($purchase->payable_amount); ?>"><i
                                                            class="ri-money-dollar-circle-fill" data-bs-toggle="tooltip"
                                                            data-bs-placement="top" title="<?php echo e(__('Give Payment')); ?>"></i></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-purchase-return')): ?>
                                                <a href="<?php echo e(route('purchase.return', $purchase->id)); ?>"
                                                    class="btn btn-icon btn-sm btn-danger" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="<?php echo e(__('Return Purchase')); ?>"><i
                                                        class="ri-arrow-go-back-line"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-purchase')): ?>
                                                <a href="<?php echo e(route('purchase.edit', $purchase->id)); ?>"
                                                    class="btn btn-icon btn-sm btn-info" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="<?php echo e(__('Edit')); ?>"><i
                                                        class="ri-edit-line"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($purchases->links('includes.__pagination')); ?>

            <?php else: ?>
                <?php echo $__env->make('includes.__empty_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>

    <?php echo $__env->make('purchase.include.__give_payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
    <script>
        $(function() {
            "use strict"
            $('.js-example-basic-single').select2();
            flatpickr("#date", {
                mode: "range",
                dateFormat: "Y-m-d",
            });
            //Give Payment Modal Click
            $(document).on('click', '.givePayment', function() {
                let id = $(this).data('id');
                let invoice = $(this).data('invoice');
                let amount = $(this).data('amount');

                $('#invoice_no_modal').val(invoice)
                $('#payable_amount_modal').val(amount)
                $('#purchase_id_modal').val(id)

            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/purchase/index.blade.php ENDPATH**/ ?>