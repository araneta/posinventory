<?php $__env->startSection('title', __('Profit Loss Report')); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Profit Loss Report')); ?></h5>
        </div>
    </div>
    <!-- Page Header Close -->
    <?php echo $__env->make('report.include.__filter_profit_loss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card custom-card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table text-nowrap">
                    <thead>
                    <tr class="text-center">
                        <th scope="col"><?php echo e(__('SN')); ?></th>
                        <th scope="col"><?php echo e(__('Type')); ?></th>
                        <th scope="col"><?php echo e(__('Amount')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr class="text-center">
                            <td>
                                <strong><?php echo e(__('1')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Total Sale')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($totalSale)); ?>

                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <strong><?php echo e(__('2')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Total Purchase')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($totalPurchase)); ?>

                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <strong><?php echo e(__('3')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Tax')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($totalTax)); ?>

                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <strong><?php echo e(__('4')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Discount')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($totalDiscount)); ?>

                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <strong><?php echo e(__('5')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Sale Return')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($totalSaleReturn)); ?>

                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <strong><?php echo e(__('6')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Purchase Return')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($totalPurchaseReturn)); ?>

                            </td>
                        </tr>
                        <tr class="text-center <?php echo e($grossProfit < 0 ? 'table-danger' : 'table-success'); ?>">
                            <td>
                                <strong><?php echo e(__('7')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Gross Profit')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($grossProfit)); ?>

                            </td>
                        </tr>
                        <tr class="text-center">
                            <td>
                                <strong><?php echo e(__('8')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Expense')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($totalExpense)); ?>

                            </td>
                        </tr>
                        <tr class="text-center <?php echo e($netProfit < 0 ? 'table-danger' : 'table-success'); ?>">
                            <td>
                                <strong><?php echo e(__('9')); ?></strong>
                            </td>
                            <td>
                                <strong><?php echo e(__('Net Profit')); ?></strong>
                            </td>
                            <td>
                                <?php echo e(showAmount($netProfit)); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
    <script>
        $(function () {
            "use strict"
            $('.js-example-basic-single').select2();
            flatpickr("#date", {
                mode: "range",
                dateFormat: "Y-m-d",
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/report/profit-loss.blade.php ENDPATH**/ ?>