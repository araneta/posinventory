<div class="table-responsive">
    <table class="table text-nowrap table-bordered">
        <thead>
            <tr>
                <th scope="col"><?php echo e(__('Warehouse Name')); ?></th>
                <th scope="col"><?php echo e(__('Stock')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($warehouse->name); ?></td>
                    <td>
                        <?php if($product->product_type == 'variation'): ?>
                            <table class="variant_table">
                                <tr>
                                    <th><?php echo e(__('Variant Name')); ?></th>
                                    <th><?php echo e(__('Variant Value')); ?></th>
                                    <th><?php echo e(__('Stock')); ?></th>
                                </tr>
                                <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($variant->name); ?></td>
                                    <td><?php echo e($variant->pivot->value); ?></td>
                                    <td><?php echo e(variant_stock_quantity($product->id, $warehouse->id, $variant->pivot->variation_id, $variant->pivot->value)); ?><?php echo e($product->unit->name); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        <?php else: ?>
                            <?php echo e(stock_quantity($product->id, $warehouse->id)); ?><?php echo e($product->unit->name); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/product/__stock_table.blade.php ENDPATH**/ ?>