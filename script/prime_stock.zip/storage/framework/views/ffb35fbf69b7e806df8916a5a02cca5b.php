<div class="card custom-card border border-primary">
    <div class="card-body">
        <form action="<?php echo e(request()->url()); ?>" method="get">
            <div class="row">
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="category" class="form-label fs-14 text-dark"><?php echo e(__('Category')); ?> <span
                                class="text-danger">*</span></label>
                        <select class="js-example-basic-single" name="category" id="category">
                            <option selected disabled><?php echo e(__('-- Select Category --')); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if(request('category') == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="brand" class="form-label fs-14 text-dark"><?php echo e(__('Brand')); ?> <span
                                class="text-danger">*</span></label>
                        <select class="js-example-basic-single" name="brand" id="brand">
                            <option selected disabled><?php echo e(__('-- Select Brand --')); ?></option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>" <?php if(request('brand') == $brand->id): echo 'selected'; endif; ?>><?php echo e($brand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="unit" class="form-label fs-14 text-dark"><?php echo e(__('Unit')); ?> <span
                                class="text-danger">*</span></label>
                        <select class="js-example-basic-single" name="unit" id="unit">
                            <option selected disabled><?php echo e(__('-- Select Unit --')); ?></option>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($unit->id); ?>" <?php if(request('unit') == $unit->id): echo 'selected'; endif; ?>><?php echo e($unit->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="type" class="form-label fs-14 text-dark"><?php echo e(__('Product Type')); ?> <span
                                class="text-danger">*</span></label>
                        <select class="js-example-basic-single" name="type" id="type">
                            <option selected disabled><?php echo e(__('-- Select Type --')); ?></option>
                            <option value="single" <?php if(request('type') == 'single'): echo 'selected'; endif; ?>><?php echo e(__('Single')); ?></option>
                            <option value="variation" <?php if(request('type') == 'variation'): echo 'selected'; endif; ?>><?php echo e(__('Variation')); ?></option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="status" class="form-label fs-14 text-dark"><?php echo e(__('Product Status')); ?> <span
                                class="text-danger">*</span></label>
                        <select class="js-example-basic-single" name="status" id="status">
                            <option selected disabled><?php echo e(__('-- Select Status --')); ?></option>
                            <option value="active" <?php if(request('status') == 'active'): echo 'selected'; endif; ?>><?php echo e(__('Active')); ?></option>
                            <option value="inactive" <?php if(request('category') == 'inactive'): echo 'selected'; endif; ?>><?php echo e(__('Inactive')); ?></option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4 mt-4">
                    <button type="submit" class="btn btn-primary label-btn mt-2 w-40">
                        <i class="ri-filter-2-fill label-btn-icon me-2"></i><?php echo e(__('Filter')); ?>

                    </button>
                    <a href="<?php echo e(route('product.index')); ?>" class="btn btn-danger label-btn mt-2 w-40">
                        <i class="ri-refresh-line label-btn-icon me-2"></i><?php echo e(__('Reset')); ?>

                    </a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/product/__filter.blade.php ENDPATH**/ ?>