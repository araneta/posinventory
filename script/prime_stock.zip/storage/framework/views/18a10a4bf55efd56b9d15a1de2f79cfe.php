<?php $__env->startSection('title', 'Not Found'); ?>

<?php $__env->startSection('content'); ?>
    <div class="notfound">
        <div class="notfound-404">
            <h1>404</h1>
        </div>
        <h2><?php echo e(__('Oopps. The page you were looking for doesn\'t exist.')); ?></h2>
        <p><?php echo e(__('You may have mistyped the address or the page may have moved.')); ?></p>
        <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Back to Homepage')); ?></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/errors/404.blade.php ENDPATH**/ ?>