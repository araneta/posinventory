<?php $__env->startSection('title', __('Sale')); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Sale')); ?></h5>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-sale')): ?>
            <div class="d-flex my-xl-auto right-content align-items-center">
                <div class="pe-1 mb-xl-0">
                    <a href="<?php echo e(route('sale.create')); ?>" class="btn btn-primary label-btn">
                        <i class="ri-add-circle-line label-btn-icon me-2"></i><?php echo e(__('Add New')); ?>

                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <!-- Page Header Close -->
    <?php echo $__env->make('sale.include.__filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card custom-card <?php echo e($sales->count() <= 0 ? 'text-center' : ''); ?>">
        <div class="card-header justify-content-between">
            <?php echo $__env->make('includes.__table_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-body">
            <?php if($sales->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table text-nowrap">
                        <thead>
                            <tr class="text-center">
                                <th scope="col"><?php echo e(__('Invoice No|Date')); ?></th>
                                <th scope="col"><?php echo e(__('Customer|Mobile')); ?></th>
                                <th scope="col"><?php echo e(__('Total Amount|Warehouse')); ?></th>
                                <th scope="col"><?php echo e(__('Discount|Tax|Receivable')); ?></th>
                                <th scope="col"><?php echo e(__('Received|Due')); ?></th>
                                <th scope="col"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td>
                                        <strong><?php echo e($sale->invoice_no); ?></strong><br>
                                        <span><?php echo e($sale->date); ?></span>
                                    </td>
                                    <td>
                                        <strong><?php echo e($sale->customer->name); ?></strong><br><span><?php echo e($sale->customer->phone); ?></span>
                                    </td>
                                    <td>
                                        <?php echo e(showAmount($sale->total_price)); ?><br>
                                        <span class="text-primary"><?php echo e($sale->warehouse->name); ?></span>
                                    </td>
                                    <td>
                                        <?php echo e(showAmount($sale->discount)); ?> <br>
                                        <?php echo e(showAmount(taxAmount($sale->total_price, $sale->tax_amount))); ?> <br>
                                        <?php echo e(showAmount($sale->receivable_amount)); ?>

                                    </td>
                                    <td>
                                        <strong><?php echo e(showAmount($sale->received_amount)); ?></strong><br>
                                        <span
                                            class="badge bg-danger-transparent"><?php echo e(showAmount($sale->receivable_amount - $sale->received_amount)); ?></span>
                                    </td>

                                    <td>
                                        <div class="hstack gap-2 fs-15">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice-sale')): ?>
                                                <a href="<?php echo e(route('sale.show', $sale->id)); ?>"
                                                    class="btn btn-icon btn-sm btn-success" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="<?php echo e(__('Invoice')); ?>"><i
                                                        class="ri-download-2-line"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receive-customer-payment')): ?>
                                                <?php if($sale->status == 'due'): ?>
                                                    <a href="javascript:void(0);"
                                                        class="btn btn-icon btn-sm btn-dark givePayment"
                                                        data-bs-target="#paymentModal" data-bs-toggle="modal"
                                                        data-id="<?php echo e($sale->id); ?>" data-invoice="<?php echo e($sale->invoice_no); ?>"
                                                        data-amount="<?php echo e($sale->receivable_amount); ?>"><i
                                                            class="ri-money-dollar-circle-fill" data-bs-toggle="tooltip"
                                                            data-bs-placement="top"
                                                            title="<?php echo e(__('Received Payment')); ?>"></i></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-sale-return')): ?>
                                                <a href="<?php echo e(route('sale.return', $sale->id)); ?>"
                                                    class="btn btn-icon btn-sm btn-danger" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="<?php echo e(__('Return Sale')); ?>"><i
                                                        class="ri-arrow-go-back-line"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-sale')): ?>
                                                <a href="<?php echo e(route('sale.edit', $sale->id)); ?>"
                                                    class="btn btn-icon btn-sm btn-info" data-bs-toggle="tooltip"
                                                    class="ri-edit-line"><i
                                                        class="ri-edit-line"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($sales->links('includes.__pagination')); ?>

            <?php else: ?>
                <?php echo $__env->make('includes.__empty_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>

    <?php echo $__env->make('sale.include.__receive_payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
    <script>
        $(function() {
            "use strict"
            $('.js-example-basic-single').select2();
            flatpickr("#date", {
                mode: "range",
                dateFormat: "Y-m-d",
            });
            //Give Payment Modal Click
            $(document).on('click', '.givePayment', function() {
                let id = $(this).data('id');
                let invoice = $(this).data('invoice');
                let amount = $(this).data('amount');
                console.log(id, invoice, amount)
                $('#invoice_no_modal').val(invoice)
                $('#receivable_amount_modal').val(amount)
                $('#purchase_id_modal').val(id)

            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/sale/index.blade.php ENDPATH**/ ?>