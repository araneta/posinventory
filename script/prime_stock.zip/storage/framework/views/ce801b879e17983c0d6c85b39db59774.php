<form action="<?php echo e(request()->url()); ?>" class="d-flex justify-content-between w-100" method="get" id="tableHeaderForm">
    <div class="card-title">
        <?php echo e(__('Show')); ?>

        &nbsp;
        <label>
            <select class="form-select" name="per_page" id="perPage">
                <option value="10" <?php echo e(request('per_page') == 10 || settings('record_to_display') == 10 ? 'selected' : ''); ?>><?php echo e(__('10')); ?></option>
                <option value="25" <?php echo e(request('per_page') == 25 || settings('record_to_display') == 25 ? 'selected' : ''); ?>><?php echo e(__('25')); ?></option>
                <option value="50" <?php echo e(request('per_page') == 50 || settings('record_to_display') == 50 ? 'selected' : ''); ?>><?php echo e(__('50')); ?></option>
                <option value="100" <?php echo e(request('per_page') == 100 || settings('record_to_display') == 100 ? 'selected' : ''); ?>><?php echo e(__('100')); ?></option>
            </select>
        </label>
        &nbsp;
        <?php echo e(__('entries')); ?>

    </div>
    <div class="prism-toggle">
        <div class="input-group">
            <label for="search"></label><input type="text" name="search" id="search" class="form-control"
                                               placeholder="<?php echo e(__('Search')); ?>" value="<?php echo e(request('search')); ?>">
            <button class="btn btn-secondary" type="submit">
                <i class="ri-search-line"></i>
            </button>
        </div>
    </div>
</form>
<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('#perPage').on('change', function () {
                $('#tableHeaderForm').submit();
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/includes/__table_header.blade.php ENDPATH**/ ?>