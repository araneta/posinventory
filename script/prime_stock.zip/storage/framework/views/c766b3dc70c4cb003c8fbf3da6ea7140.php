<div class="modal fade" id="modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title" id="title"></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('widget-update')); ?>" method="POST" id="form">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <ul class="list-group">
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_products']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Products')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_products" <?php if(isset($widget['total_products'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_customers']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Customers')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_customers" <?php if(isset($widget['total_customers'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_suppliers']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Suppliers')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_suppliers" <?php if(isset($widget['total_suppliers'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_category']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Category')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_category" <?php if(isset($widget['total_category'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_sale']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Sale')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_sale" <?php if(isset($widget['total_sale'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_sale_amount']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Sale Amount')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_sale_amount" <?php if(isset($widget['total_sale_amount'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_sale_return']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Sale Return')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_sale_return" <?php if(isset($widget['total_sale_return'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_sale_return_amount']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Sale Return Amount')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_sale_return_amount" <?php if(isset($widget['total_sale_return_amount'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_purchase']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Purchase')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_purchase" <?php if(isset($widget['total_purchase'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_purchase_amount']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Purchase Amount')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_purchase_amount" <?php if(isset($widget['total_purchase_amount'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_purchase_return']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Purchase Return')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_purchase_return" <?php if(isset($widget['total_purchase_return'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['total_purchase_return_amount']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Total Purchase Return Amount')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="total_purchase_return_amount" <?php if(isset($widget['total_purchase_return_amount'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['purchase_sale_report']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Purchase Sale Report')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="purchase_sale_report" <?php if(isset($widget['purchase_sale_report'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['top_selling_product']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Top Selling Product')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="top_selling_product" <?php if(isset($widget['top_selling_product'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center fw-semibold <?php echo e(isset($widget['stock_level_alert']) ? '' : 'text-decoration-line-through'); ?>">
                            <?php echo e(__('Stock Level Alert')); ?>

                            <div class="form-check form-check-lg form-switch">
                                <input class="form-check-input" type="checkbox" role="switch"
                                       name="stock_level_alert" <?php if(isset($widget['stock_level_alert'])): echo 'checked'; endif; ?>>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                            data-bs-dismiss="modal"><?php echo e(__('Close')); ?>

                    </button>
                    <button type="submit" class="btn btn-primary" id="submitBtn"><?php echo e(__('Save changes')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/includes/__widget_handle.blade.php ENDPATH**/ ?>