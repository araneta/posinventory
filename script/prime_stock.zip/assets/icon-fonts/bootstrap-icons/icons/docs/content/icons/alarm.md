---
title: Alarm
categories:
  - Devices
tags:
  - alarm
  - clock
  - time
---
