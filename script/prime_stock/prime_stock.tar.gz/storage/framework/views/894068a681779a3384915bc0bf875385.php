

<?php $__env->startSection('title', __('Purchase Return')); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Purchase Return')); ?></h5>
        </div>
    </div>
    <!-- Page Header Close -->
    <?php echo $__env->make('purchase.include.__filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card custom-card <?php echo e($purchases->count() <= 0 ? 'text-center' : ''); ?>">
        <div class="card-header justify-content-between">
            <?php echo $__env->make('includes.__table_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-body">
            <?php if($purchases->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table text-nowrap">
                        <thead>
                            <tr class="text-center">
                                <th scope="col"><?php echo e(__('Invoice No|Date')); ?></th>
                                <th scope="col"><?php echo e(__('Supplier|Mobile')); ?></th>
                                <th scope="col"><?php echo e(__('Total Amount|Warehouse')); ?></th>
                                <th scope="col"><?php echo e(__('Lessed|Receivable')); ?></th>
                                <th scope="col"><?php echo e(__('Received|Due')); ?></th>
                                <th scope="col"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td>
                                        <strong><?php echo e($purchase->invoice_no); ?></strong><br>
                                        <span><?php echo e($purchase->return_date); ?></span>
                                    </td>
                                    <td>
                                        <strong><?php echo e($purchase->supplier->name); ?></strong><br><span><?php echo e($purchase->supplier->phone); ?></span>
                                    </td>
                                    <td>
                                        <?php echo e(showAmount($purchase->return_amount)); ?><br>
                                        <span class="text-primary"><?php echo e($purchase->warehouse->name); ?></span>
                                    </td>
                                    <td>
                                        <?php echo e(showAmount($purchase->return_discount)); ?> <br>
                                        <?php echo e(showAmount($purchase->receivable_amount)); ?>

                                    </td>
                                    <td>
                                        <strong><?php echo e(showAmount($purchase->received_amount)); ?></strong><br>
                                        <span
                                            class="badge bg-danger-transparent"><?php echo e(showAmount($purchase->receivable_amount - $purchase->received_amount)); ?></span>
                                    </td>

                                    <td>
                                        <div class="hstack gap-2 fs-15">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice-purchase-return')): ?>
                                                <a href="<?php echo e(route('purchase.return.show', $purchase->id)); ?>"
                                                    class="btn btn-icon btn-sm btn-success" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="<?php echo e(__('Invoice')); ?>"><i
                                                        class="ri-download-2-line"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receive-supplier-payment')): ?>
                                                <?php if($purchase->return_status == 'due'): ?>
                                                    <a href="javascript:void(0);"
                                                        class="btn btn-icon btn-sm btn-dark receivePayment"
                                                        data-bs-target="#paymentModal" data-bs-toggle="modal"
                                                        data-id="<?php echo e($purchase->id); ?>"
                                                        data-invoice="<?php echo e($purchase->invoice_no); ?>"
                                                        data-amount="<?php echo e($purchase->receivable_amount); ?>"><i
                                                            class="ri-money-dollar-circle-fill" data-bs-toggle="tooltip"
                                                            data-bs-placement="top"
                                                            title="<?php echo e(__('Receive Payment')); ?>"></i></a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-purchase-return')): ?>
                                                <a href="<?php echo e(route('purchase-return.edit', $purchase->id)); ?>"
                                                    class="btn btn-icon btn-sm btn-info" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="<?php echo e(__('Edit')); ?>"><i
                                                        class="ri-edit-line"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($purchases->links('includes.__pagination')); ?>

            <?php else: ?>
                <?php echo $__env->make('includes.__empty_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>

    <?php echo $__env->make('purchase.include.__receive_payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
    <script>
        $(function() {
            "use strict"
            $('.js-example-basic-single').select2();
            flatpickr("#date", {
                mode: "range",
                dateFormat: "Y-m-d",
            });
            //Give Payment Modal Click
            $(document).on('click', '.receivePayment', function() {
                let id = $(this).data('id');
                let invoice = $(this).data('invoice');
                let amount = $(this).data('amount');

                $('#invoice_no_modal').val(invoice)
                $('#receivable_amount_modal').val(amount)
                $('#purchase_id_modal').val(id)

            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/purchase/return_list.blade.php ENDPATH**/ ?>