<?php $__env->startSection('title', __('Language Settings')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Language Settings')); ?></h5>
        </div>

        <div class="d-flex my-xl-auto right-content align-items-center">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sync-language')): ?>
                <div class="pe-1 mb-xl-0">
                    <a href="<?php echo e(route('language-sync-missing')); ?>" class="btn btn-dark label-btn">
                        <i class="ri-refresh-line label-btn-icon me-2"></i><?php echo e(__('Sync Missing Translation Keys')); ?>

                    </a>
                </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-language')): ?>
                <div class="pe-1 mb-xl-0">
                    <a href="<?php echo e(route('language.create')); ?>" class="btn btn-primary label-btn">
                        <i class="ri-add-circle-line label-btn-icon me-2"></i><?php echo e(__('Add New')); ?>

                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- Page Header Close -->
    <div class="card custom-card <?php echo e($languages->count() <= 0 ? 'text-center' : ''); ?>">
        <div class="card-header justify-content-between">
            <?php echo $__env->make('includes.__table_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-body">
            <?php if($languages->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table text-nowrap">
                        <thead>
                            <tr>
                                <th scope="col"><?php echo e(__('Language Name')); ?></th>
                                <th scope="col"><?php echo e(__('Status')); ?></th>
                                <th scope="col"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar avatar-sm me-2 avatar-rounded">
                                                <img src="<?php echo e($language->flag !== null ? asset('assets/images/language/' . $language->flag) : asset('assets/images/language.png')); ?>"
                                                    alt="img" />
                                            </div>
                                            <div class="ms-2">
                                                <div class="lh-1">
                                                    <span class="fw-bold fs-18"><?php echo e($language->name); ?></span>
                                                    <?php if($language->is_default): ?>
                                                        <span
                                                            class="badge rounded-pill bg-success ms-2 p-2"><?php echo e(__('Default')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="lh-1 mt-2">
                                                    <span class="fs-14"><?php echo e($language->locale); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($language->status): ?>
                                            <span
                                                class="badge rounded-pill bg-success-gradient p-2"><?php echo e(__('Active')); ?></span>
                                        <?php else: ?>
                                            <span
                                                class="badge rounded-pill bg-danger-gradient p-2"><?php echo e(__('Deactivate')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="hstack gap-2 flex-wrap">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('translate-language')): ?>
                                            <a href="<?php echo e(route('language-keyword', $language->locale)); ?>"
                                                class="btn btn-dark btn-icon rounded-pill btn-wave btn-sm"
                                                data-bs-toggle="tooltip" data-bs-placement="top"
                                                title="<?php echo e(__('Language Keyword')); ?>"><i class="ri-global-line"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-language')): ?>
                                            <a href="<?php echo e(route('language.edit', $language)); ?>"
                                                class="btn btn-primary btn-icon rounded-pill btn-wave btn-sm"
                                                data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="<?php echo e(__('Edit Language')); ?>"><i class="ri-edit-line"></i></a>
                                            <?php endif; ?>
                                            <?php if(!$language->is_default): ?>
                                                <button data-id="<?php echo e($language->id); ?>"
                                                    class="btn btn-danger btn-icon rounded-pill btn-wave btn-sm dltBtn"
                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="<?php echo e(__('Delete Language')); ?>"><i
                                                        class="ri-delete-bin-5-line"></i></button>
                                                <form action="" id="dltForm" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($languages->links('includes.__pagination')); ?>

            <?php else: ?>
                <?php echo $__env->make('includes.__empty_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(function() {
            "use strict"
            var options = {
                'position': 'top-right'
            }
            var notifier = new AWN(options);
            $(document).on('click', '.dltBtn', function() {
                let onOk = () => {
                    var id = $(this).data('id');
                    var url = '<?php echo e(route('language.destroy', ':id')); ?>';
                    url = url.replace(':id', id);
                    $('#dltForm').attr('action', url);
                    $('#dltForm').submit();
                };
                let onCancel = () => {
                    notifier.info('Your Item is safe')
                };
                notifier.confirm('Are you sure you want to delete the items', onOk, onCancel)
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/language/index.blade.php ENDPATH**/ ?>