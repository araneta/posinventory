<?php $__env->startSection('title', __('Login')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">
        <h4 class="card-title"><?php echo e(__('Sign In')); ?></h4>
        <?php if(session('error')): ?>
            <p class="text-danger"><?php echo e(session('error')); ?></p>
        <?php endif; ?>
        <form action="<?php echo e(route('login')); ?>" method="POST" class="signin-form">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="email"><?php echo e(__('Email')); ?></label>
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                    placeholder="Email" required autofocus autocomplete="username" value="<?php if(appMode() == 'demo'): ?><?php echo e('admin@gmail.com'); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password"><?php echo e(__('Password')); ?>

                    <?php if(Route::has('password.request')): ?>
                        <a href="<?php echo e(route('password.request')); ?>" class="float-right">
                            <?php echo e(__('Forgot Password?')); ?>

                        </a>
                    <?php endif; ?>
                </label>
                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="password" equired autocomplete="current-password" value="<?php if(appMode() == 'demo'): ?><?php echo e('password'); ?><?php endif; ?>" placeholder="Password" data-eye>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <div class="custom-checkbox custom-control">
                    <input type="checkbox" name="remember_me" id="remember" class="custom-control-input">
                    <label for="remember" class="custom-control-label"><?php echo e(__('Remember Me')); ?></label>
                </div>
            </div>

            <div class="form-group m-0">
                <button type="submit" class="btn btn-primary btn-block">
                    <?php echo e(__('Sign In')); ?>

                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('#copy_btn').on('click', function() {
                var email = $('tbody tr th').text().trim();
                var password = $('tbody tr td:first').text().trim();
                $('input[name="email"]').val(email);
                $('input[name="password"]').val(password);

                // Submit the form
                $('form').submit();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/auth/login.blade.php ENDPATH**/ ?>