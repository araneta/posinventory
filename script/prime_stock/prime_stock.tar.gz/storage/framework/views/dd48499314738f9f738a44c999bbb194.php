<!doctype html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Maven+Pro:400,900" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('assets/uploads')); ?>/<?php echo e(settings('favicon')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/error/css/style.css')); ?>">

</head>

<body>
    <div id="notfound">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/layouts/error.blade.php ENDPATH**/ ?>