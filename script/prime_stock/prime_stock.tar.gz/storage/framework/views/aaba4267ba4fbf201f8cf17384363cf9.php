<?php $__env->startSection('title', __('Variations')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mt-3">
        <div class="col-md-4">
            <div class="card custom-card collapse-card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <div class="card-title mb-0" id="title">
                        <?php echo e(__('Add Variations')); ?>

                    </div>
                    <div>
                        <a href="<?php echo e(route('variation.index')); ?>" class="mx-2"><i class="ri-refresh-line fs-18"></i></a>
                        <a href="javascript:void(0);" data-bs-toggle="collapse" data-bs-target="#collapseExample"
                            aria-expanded="false" aria-controls="collapseExample">
                            <i class="ri-arrow-down-s-line fs-18 collapse-open"></i>
                            <i class="ri-arrow-up-s-line collapse-close fs-18"></i>
                        </a>
                    </div>
                </div>
                <div class="collapse show" id="collapseExample">
                    <form action="<?php echo e(route('variation.store')); ?>" method="POST" id="unitForm">
                        <?php echo csrf_field(); ?>
                        <div id="method_sec">
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="name" class="form-label fs-14 text-dark"><?php echo e(__('Name')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name"
                                    placeholder="Enter name">
                            </div>
                            <div class="mb-3">
                                <label for="values" class="form-label fs-14 text-dark"><?php echo e(__('Values')); ?> <span
                                        class="text-danger">*</span></label>
                                <div class="row default_html">
                                    <div class="col-10">
                                        <input type="text" class="form-control" id="values" name="values[]"
                                            placeholder="Enter values">
                                    </div>
                                    <div class="col-2">
                                        <button type="button" class="btn btn-primary btn-sm" id="addMore"><i
                                                class="ri-add-line"></i></button>
                                    </div>
                                </div>
                                <div id="insert_field">

                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-variation')): ?>
                                <button class="btn btn-primary" type="submit"><?php echo e(__('Save Changes')); ?></button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card custom-card <?php echo e($variations->count() <= 0 ? 'text-center' : ''); ?>">
                <div class="card-header justify-content-between">
                    <?php echo $__env->make('includes.__table_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body">
                    <?php if($variations->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table text-nowrap">
                                <thead>
                                    <tr>
                                        <th scope="col"><?php echo e(__('Name')); ?></th>
                                        <th scope="col"><?php echo e(__('Values')); ?></th>
                                        <th scope="col"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($variation->name); ?></td>
                                            <td>
                                                <?php echo arrayBadge($variation->values); ?>

                                            </td>
                                            <td>
                                                <div class="hstack gap-2 flex-wrap">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-variation')): ?>
                                                        <a href="javascript:void(0);" data-id="<?php echo e($variation->id); ?>"
                                                            data-name="<?php echo e($variation->name); ?>"
                                                            data-values="<?php echo e(arrayToString($variation->values)); ?>"
                                                            class="btn btn-primary btn-icon rounded-pill btn-wave btn-sm editBtn"
                                                            data-bs-toggle="tooltip" data-bs-placement="top"
                                                            title="<?php echo e(__('Edit')); ?>"><i class="ri-edit-line"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-variation')): ?>
                                                        <button data-id="<?php echo e($variation->id); ?>"
                                                            class="btn btn-danger btn-icon rounded-pill btn-wave btn-sm dltBtn"
                                                            data-bs-toggle="tooltip" data-bs-placement="top"
                                                            title="<?php echo e(__('Delete')); ?>"><i
                                                                class="ri-delete-bin-5-line"></i></button>
                                                    <?php endif; ?>
                                                    <form action="" id="dltForm" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo e($variations->links('includes.__pagination')); ?>

                    <?php else: ?>
                        <?php echo $__env->make('includes.__empty_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(function() {
            "use strict"
            var options = {
                'position': 'top-right'
            }
            var notifier = new AWN(options);
            //Edit Event
            $(document).on('click', '.editBtn', function() {
                let id = $(this).data('id');
                let name = $(this).data('name');
                let values = $(this).data('values');
                $("#title").html('<?php echo e(__('Edit Units')); ?>')
                $("#name").val(name)
                $('#insert_field').html('');
                $('.default_html').html('');
                // value is comma separated string and first item show add more button but another item show remove button
                values = values.split(',');
                values.forEach(function(value, index) {
                    let html;
                    if (index === 0) {
                        html =
                            '<div class="row mt-2"><div class="col-10"><input type="text" class="form-control" id="values" name="values[]" value="' +
                            value +
                            '" placeholder="Values"></div><div class="col-2"><button type="button" class="btn btn-primary btn-sm" id="addMore"><i class="ri-add-line"></i></button></div></div>';
                    } else {
                        html =
                            '<div class="row mt-2"><div class="col-10"><input type="text" class="form-control" id="values" name="values[]" value="' +
                            value +
                            '" placeholder="Values"></div><div class="col-2"><button type="button" class="btn btn-danger btn-sm" id="removeField"><i class="ri-close-line"></i></button></div></div>';
                    }
                    $('#insert_field').append(html);
                })

                let url = '<?php echo e(route('variation.update', ':id')); ?>';
                url = url.replace(':id', id);
                $('#unitForm').attr('action', url);
                $('#method_sec').html('<input type="hidden" name="_method" value="PUT">')
            })

            // add more field
            $(document).on('click', '#addMore', function() {
                const html =
                    '<div class="row mt-2"><div class="col-10"><input type="text" class="form-control" id="values" name="values[]" placeholder="Values"></div><div class="col-2"><button type="button" class="btn btn-danger btn-sm" id="removeField"><i class="ri-close-line"></i></button></div></div>';
                $('#insert_field').append(html);
            })
            // remove field
            $(document).on('click', '#removeField', function() {
                $(this).closest('.row').remove();
            })

            //Delete Event
            $(document).on('click', '.dltBtn', function() {
                let onOk = () => {
                    const id = $(this).data('id');
                    let url = '<?php echo e(route('variation.destroy', ':id')); ?>';
                    url = url.replace(':id', id);
                    $('#dltForm').attr('action', url);
                    $('#dltForm').submit();
                };
                let onCancel = () => {
                    notifier.info('Your Item is safe')
                };
                notifier.confirm('<?php echo e(__('Are you sure you want to delete the items')); ?>', onOk, onCancel)
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/variations/index.blade.php ENDPATH**/ ?>