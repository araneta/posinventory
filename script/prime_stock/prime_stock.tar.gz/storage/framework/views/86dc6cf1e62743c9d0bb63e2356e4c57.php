<!-- JQuery -->
<script src="<?php echo e(asset('assets/libs/jquery/jquery-3.7.1.min.js')); ?>"></script>
<!-- Popper JS -->
<script src="<?php echo e(asset('assets/libs/@popperjs/core/umd/popper.min.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Defaultmenu JS -->
<script src="<?php echo e(asset('assets/js/defaultmenu.min.js')); ?>"></script>
<!-- Node Waves JS-->
<script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>
<!-- Sticky JS -->
<script src="<?php echo e(asset('assets/js/sticky.js')); ?>"></script>
<!-- Simplebar JS -->
<script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/simplebar.js')); ?>"></script>
<!-- Color Picker JS -->
<script src="<?php echo e(asset('assets/libs/@simonwep/pickr/pickr.es5.min.js')); ?>"></script>
<!-- Custom-Switcher JS -->
<script src="<?php echo e(asset('assets/js/custom-switcher.min.js')); ?>"></script>
<!-- Notification JS -->
<script src="<?php echo e(asset('assets/libs/awesome-notifications/index.var.js')); ?>"></script>

<!-- Notification Custom JS -->
<script>
    $(function(){
        `use strict`

        var options = {
            'position' : 'top-right'
        }
        var notifier = new AWN(options);

        <?php if(Session::has('success')): ?>
            notifier.success("<?php echo e(session('success')); ?>")
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            notifier.alert("<?php echo e(session('error')); ?>")
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            notifier.info("<?php echo e(session('info')); ?>")
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            notifier.warning("<?php echo e(session('warning')); ?>")
        <?php endif; ?>

        $(document).on('keyup', '#barcode_search', function () {
            let value = $(this).val();
            if (value.length > 3) {
                $.ajax({
                    url: '<?php echo e(route('barcode.search')); ?>',
                    method: 'POST',
                    data: {
                        barcode: value
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function (response) {
                        if (response != '') {
                            let searchCard = $('.search-card');
                            searchCard.removeClass('d-none');
                            $('.search-card .card-body').html(response);
                        } else {
                            $('.search-card').removeClass('d-none');
                            let html = `<p class="text-center align-middle">No product found</p>`;
                            $('.search-card .card-body').html(html);
                        }
                    },
                    error: function (error) {
                        console.log(error);
                    }
                })
            } else {
                $('.search-card').removeClass('d-none');
                let html = `<p class="text-center align-middle">Please write atleast 3 character</p>`;
                $('.search-card .card-body').html(html);
            }
        });
    })
</script>

<!-- Custom JS -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/floating.js')); ?>"></script>
<?php echo $__env->yieldPushContent('script'); ?>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/layouts/partials/__script.blade.php ENDPATH**/ ?>