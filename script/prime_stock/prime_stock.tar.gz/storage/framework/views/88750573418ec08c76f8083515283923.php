<!doctype html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900&display=swap" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('assets/uploads')); ?>/<?php echo e(settings('favicon')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/login/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/login/css/style.css')); ?>">

</head>

<body class="my-login-page">
    <section class="h-100">
        <div class="container h-100">
            <div class="row justify-content-md-center h-100">
                <div class="card-wrapper">
                    <div class="brand">
                        <img src="<?php echo e(asset('assets/uploads')); ?>/<?php echo e(settings('favicon')); ?>" alt="logo">
                    </div>
                    <div class="card fat">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <div class="footer">
                        <?php echo e(settings('footer_text')); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="<?php echo e(asset('assets/login/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/login/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/login/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/login/js/main.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/layouts/guest.blade.php ENDPATH**/ ?>