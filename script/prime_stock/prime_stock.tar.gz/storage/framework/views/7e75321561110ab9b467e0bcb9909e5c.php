<?php $__env->startSection('title', __('Sale Details')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Sale Details')); ?></h5>
        </div>

        <div class="d-flex my-xl-auto right-content align-items-center">
            <div class="pe-1 mb-xl-0">
                <a href="<?php echo e(route('sale.index')); ?>" class="btn btn-danger label-btn">
                    <i class="ri-arrow-go-back-line label-btn-icon me-2"></i><?php echo e(__('Back')); ?>

                </a>
            </div>
        </div>
    </div>
    <!-- Page Header Close -->

    <!-- Purchase Details -->
    <div class="row">
        <div class="col-md-12 col-xl-12">
            <div class="main-content-body-invoice">
                <div class="card card-invoice">
                    <div class="card-body">
                        <div class="invoice-header">
                            <h2 class="invoice-title"><?php echo e(__('Invoice')); ?> #<?php echo e($sale->invoice_no); ?></h2>
                            <?php echo generateQRCode(route('sale.show', $sale->id)); ?>

                            <div class="billed-from">
                                <h6><?php echo e(settings('company_name')); ?></h6>
                                <p><?php echo e(settings('company_address')); ?><br>
                                    <?php echo e(__('Tel No')); ?>: <?php echo e(settings('company_phone')); ?><br>
                                    <?php echo e(__('Email')); ?>: <?php echo e(settings('company_email')); ?></p>
                            </div><!-- billed-from -->
                        </div><!-- invoice-header -->
                        <div class="row mt-4">
                            <div class="col-md">
                                <label class="text-gray-6"><?php echo e(__('Billed To')); ?></label>
                                <div class="billed-to">
                                    <h6 class="fs-14 fw-semibold"><?php echo e($sale->customer->name); ?></h6>
                                    <p><?php echo e($sale->customer->address); ?><br>
                                        <?php echo e(__('Tel No')); ?>: <?php echo e($sale->customer->phone); ?><br>
                                        <?php echo e(__('Email')); ?>: <?php echo e($sale->customer->email); ?></p>
                                </div>
                            </div>
                            <div class="col-md">
                                <label class="text-gray-6"><?php echo e(__('Invoice Information')); ?></label>
                                <p class="invoice-info-row"><span><?php echo e(__('Invoice No')); ?></span> <span><?php echo e($sale->invoice_no); ?></span></p>
                                <p class="invoice-info-row"><span><?php echo e(__('Warehouse')); ?></span> <span><?php echo e($sale->warehouse->name ?? 'N/A'); ?></span></p>
                                <p class="invoice-info-row"><span><?php echo e(__('Sale Date')); ?>:</span> <span><?php echo e($sale->date ?? 'N/A'); ?></span></p>
                                <p class="invoice-info-row"><span><?php echo e(__('Status')); ?>:</span> <span><?php echo e($sale->status ?? 'N/A'); ?></span></p>
                            </div>
                        </div>
                        <div class="table-responsive mt-4">
                            <table class="table table-invoice border text-md-nowrap mb-0">
                                <thead>
                                <tr>
                                    <th class="w-20"><?php echo e(__('Product')); ?></th>
                                    <th class="w-40"><?php echo e(__('Code')); ?></th>
                                    <th class="text-center"><?php echo e(__('Quantity')); ?></th>
                                    <th><?php echo e(__('Unit Price')); ?></th>
                                    <th><?php echo e(__('Total Amount')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $sale->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->name); ?>

                                            <?php if($product->product_type == 'variation'): ?>
                                                <p class="text-muted mb-0"><?php echo e(variationName($product->pivot->variation_id)); ?>: <?php echo e($product->pivot->variation_value); ?></p>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($product->code); ?></td>
                                        <td class="text-center"><?php echo e($product->pivot->quantity); ?> <?php echo e($product->unit->name); ?></td>
                                        <td><?php echo e(showAmount($product->pivot->price)); ?></td>
                                        <td><?php echo e(showAmount($product->pivot->total_price)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-top" colspan="2" rowspan="4">
                                        <div class="invoice-notes">
                                            <label class="main-content-label fs-13"><?php echo e(__('Notes')); ?></label>
                                            <p class="fw-normal fs-13"><?php echo e($sale->sale_note); ?></p>
                                        </div><!-- invoice-notes -->
                                    </td>
                                    <td><?php echo e(__('Sub-Total')); ?></td>
                                    <td colspan="2"><?php echo e(showAmount($sale->receivable_amount)); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e(__('Tax')); ?> (<?php echo e($sale->tax_amount); ?>%)</td>
                                    <td colspan="2"><?php echo e(showAmount(taxAmount($sale->total_price, $sale->tax_amount))); ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo e(__('Discount')); ?></td>
                                    <td colspan="2">-<?php echo e(showAmount($sale->discount)); ?></td>
                                </tr>
                                <tr>
                                    <td class=" text-uppercase tx-inverse"><?php echo e(__('Total Due')); ?></td>
                                    <td colspan="2">
                                        <h4 class="text-danger"><?php echo e(showAmount($sale->dueAmount())); ?></h4>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>

                        <a href="javascript:void(0);" class="btn btn-danger float-end mt-3 ms-2 btn_print">
                            <i class="mdi mdi-printer me-1"></i><?php echo e(__('Print')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div><!-- COL-END -->
    </div>
    <!--End::row-1 -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jquery-ui/js/jquery-ui.min.js')); ?>"></script>
    <script>
        $(function () {
            "use strict"
            // print function to print the invoice
            $('.btn_print').on('click', function () {
                let printContents = $('.card-invoice').html();
                let originalContents = document.body.innerHTML;
                document.body.innerHTML = printContents;
                window.print();
            });

            /**
             * if print window close then reload the page
             */
            window.onafterprint = function () {
                location.reload();
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/sale/invoice.blade.php ENDPATH**/ ?>