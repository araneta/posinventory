<?php $__env->startSection('title', __('Server Information')); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Server Information')); ?></h5>
        </div>
    </div>
    <!-- Page Header Close -->
    <div class="card custom-card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table text-nowrap">
                    <tbody>
                    <tr>
                        <td>
                            <strong><?php echo e(__('PHP Version')); ?></strong>
                        </td>
                        <td>
                            <?php echo e(phpversion()); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong><?php echo e(__('Server Software')); ?></strong>
                        </td>
                        <td>
                            <?php echo e($_SERVER['SERVER_SOFTWARE']); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong><?php echo e(__('Server IP Address')); ?></strong>
                        </td>
                        <td>
                            <?php echo e($_SERVER['SERVER_ADDR']); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong><?php echo e(__('Server Protocol')); ?></strong>
                        </td>
                        <td>
                            <?php echo e($_SERVER['SERVER_PROTOCOL']); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong><?php echo e(__('HTTP Host')); ?></strong>
                        </td>
                        <td>
                            <?php echo e($_SERVER['HTTP_HOST']); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong><?php echo e(__('Server Port')); ?></strong>
                        </td>
                        <td>
                            <?php echo e($_SERVER['SERVER_PORT']); ?>

                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/extra/server.blade.php ENDPATH**/ ?>