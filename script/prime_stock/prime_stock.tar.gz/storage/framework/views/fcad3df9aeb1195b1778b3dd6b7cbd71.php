<?php $__env->startSection('title', __('Product')); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>">
    <style>
        .variant_table {
            border-collapse: collapse;
        }

        .variant_table th,
        .variant_table td {
            border: 1px dashed #0a0808;
            padding: 5px;
            color: unset;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('Product')); ?></h5>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-product')): ?>
            <div class="d-flex my-xl-auto right-content align-items-center">
                <div class="pe-1 mb-xl-0">
                    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary label-btn">
                        <i class="ri-add-circle-line label-btn-icon me-2"></i><?php echo e(__('Add New')); ?>

                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php echo $__env->make('product.__filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Header Close -->
    <div class="card custom-card <?php echo e($products->count() <= 0 ? 'text-center' : ''); ?>">
        <div class="card-header justify-content-between">
            <?php echo $__env->make('includes.__table_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-body">
            <?php if($products->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table text-nowrap">
                        <thead>
                            <tr class="text-center">
                                <th scope="col"><?php echo e(__('Image')); ?></th>
                                <th scope="col"><?php echo e(__('Name|SKU|Type|Code')); ?></th>
                                <th scope="col"><?php echo e(__('Price|Sale Price')); ?></th>
                                <th scope="col"><?php echo e(__('Category|Brand|unit')); ?></th>
                                <th scope="col"><?php echo e(__('Stock')); ?></th>
                                <th scope="col"><?php echo e(__('Total Sale|Alert Qty')); ?></th>
                                <th scope="col"><?php echo e(__('Status')); ?></th>
                                <th scope="col"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td>
                                        <img alt="avatar" class="img-thumbnail" width="64px"
                                            src="<?php echo e(asset('assets/images/' . $product->image)); ?>">
                                    </td>
                                    <td>
                                        <strong><?php echo e($product->name); ?></strong><br><small><?php echo e($product->sku); ?></small>
                                        <br><strong><?php echo e(ucwords($product->product_type)); ?></strong>
                                        <br><small><?php echo e($product->code); ?></small>
                                    </td>
                                    <td>

                                        <?php if($product->product_type == 'variation'): ?>
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#variationModal" data-value="<?php echo e($product->id); ?>">
                                                <i class="ri-eye-fill" data-bs-toggle="tooltip" data-bs-target="top"
                                                    title="View Variation Product Price With Details"></i>
                                            <?php else: ?>
                                                <strong><?php echo e(showAmount($product->price)); ?></strong><br>
                                                <small><?php echo e(showAmount($product->sale_price)); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($product->category->name); ?><br>
                                        <small class="text-primary"><?php echo e($product->brand->name); ?></small><br>
                                        <small class="text-success"><?php echo e(ucwords($product->unit->name)); ?></small>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                            data-value="<?php echo e($product->id); ?>" data-bs-target="#stockModal">
                                            <i class="ri-eye-fill" data-bs-toggle="tooltip" data-bs-target="top"
                                                title="View Stock Wirehouse Wise"></i>
                                    </td>
                                    <td>
                                        <strong><?php echo e($product->totalSale()); ?> items</strong><br>
                                        <?php if($product->product_type == 'variation'): ?>
                                            <span class="badge bg-info-transparent"><i class="ri-information-fill" data-bs-toggle="tooltip" data-bs-target="top"
                                                title="This is a variation product you can view alert quantity in variation modal"></i></span>
                                        <?php else: ?>
                                            <span class="badge bg-info-transparent"><?php echo e($product->alert_quantity); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($product->status): ?>
                                            <span
                                                class="badge rounded-pill bg-success-gradient p-2"><?php echo e(__('Active')); ?></span>
                                        <?php else: ?>
                                            <span
                                                class="badge rounded-pill bg-danger-gradient p-2"><?php echo e(__('Deactivate')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="hstack gap-2 flex-wrap">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-product')): ?>
                                                <a href="<?php echo e(route('product.edit', $product)); ?>"
                                                    class="btn btn-primary btn-icon rounded-pill btn-wave btn-sm"
                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="<?php echo e(__('Edit')); ?>"><i class="ri-edit-line"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($products->links('includes.__pagination')); ?>

            <?php else: ?>
                <?php echo $__env->make('includes.__empty_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>

    <?php echo $__env->make('product.__variant_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('product.__warehouse_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            "use strict"
            $('.js-example-basic-single').select2();
            $('#variationModal').on('show.bs.modal', function(event) {
                let button = $(event.relatedTarget);
                let productId = button.data('value');
                console.log(productId);
                $.ajax({
                    url: "<?php echo e(route('product.variant')); ?>",
                    type: 'GET',
                    data: {
                        productId: productId
                    },
                    success: function(response) {
                        $('#variationModal .modal-body').html(response);
                    }
                })
            });

            // warehouse model
            $('#stockModal').on('show.bs.modal', function(event) {
                let button = $(event.relatedTarget);
                let productId = button.data('value');
                console.log(productId);
                $.ajax({
                    url: "<?php echo e(route('product.stock')); ?>",
                    type: 'GET',
                    data: {
                        productId: productId
                    },
                    success: function(response) {
                        $('#stockModal .modal-body').html(response);
                    }
                })
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/product/index.blade.php ENDPATH**/ ?>