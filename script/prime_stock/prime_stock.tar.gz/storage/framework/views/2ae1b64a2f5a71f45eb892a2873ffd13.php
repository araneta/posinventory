<?php $__env->startSection('title', __('System Settings')); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/filepond/filepond.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/filepond-plugin-image-preview/filepond-plugin-image-preview.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <div class="my-auto">
            <h5 class="page-title fs-21 mb-1"><?php echo e(__('System Settings')); ?></h5>
        </div>
    </div>
    <!-- Page Header Close -->
    <div class="row justify-content-center mt-3">
        <div class="col-md-12">
            <div class="card custom-card">
                <div class="card-body">
                    <form action="<?php echo e(route('settings.update')); ?>" class="row g-3" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="company_name" class="form-label fs-14 text-dark"><?php echo e(__('Company Name')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="company_name" name="company_name"
                                       value="<?php echo e(settings('company_name')); ?>" placeholder="Enter company name">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="company_phone" class="form-label fs-14 text-dark"><?php echo e(__('Company Phone')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="company_phone" name="company_phone"
                                       value="<?php echo e(settings('company_phone')); ?>" placeholder="Enter company phone">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="company_email" class="form-label fs-14 text-dark"><?php echo e(__('Company Email')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="company_email" name="company_email"
                                       value="<?php echo e(settings('company_email')); ?>" placeholder="Enter company email">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="footer_text" class="form-label fs-14 text-dark"><?php echo e(__('Footer Text')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="footer_text" name="footer_text"
                                       value="<?php echo e(settings('footer_text')); ?>" placeholder="Enter footer text">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="site_title" class="form-label fs-14 text-dark"><?php echo e(__('Site Title')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="site_title" name="site_title"
                                       value="<?php echo e(settings('site_title')); ?>" placeholder="Enter site title">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="currency" class="form-label fs-14 text-dark"><?php echo e(__('Currency')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="currency" name="currency"
                                       value="<?php echo e(settings('currency')); ?>" placeholder="Enter currency">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="currency_symbol" class="form-label fs-14 text-dark"><?php echo e(__('Currency Symbol')); ?> <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="currency_symbol" name="currency_symbol"
                                       value="<?php echo e(settings('currency_symbol')); ?>" placeholder="Enter currency symbol">
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="timezone" class="form-label fs-14 text-dark"><?php echo e(__('Timezone')); ?> <span
                                        class="text-danger">*</span></label>
                                <select class="js-example-basic-single" name="timezone" id="timezone">
                                    <option selected disabled><?php echo e(__('-- Select Timezone --')); ?></option>
                                    <?php $__currentLoopData = timezone(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['tzCode']); ?>" <?php echo e(settings('timezone') == $value['tzCode'] ? 'selected' : ''); ?>><?php echo e($value['tzCode']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="record_to_display" class="form-label fs-14 text-dark"><?php echo e(__('Record to display per page')); ?> <span
                                        class="text-danger">*</span></label>
                                <select class="js-example-basic-single" name="record_to_display" id="record_to_display">
                                    <option selected disabled><?php echo e(__('-- Select Record to display per page --')); ?></option>
                                    <?php $__currentLoopData = [10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>" <?php echo e(settings('record_to_display') == $value ? 'selected' : ''); ?>><?php echo e($value); ?> items per page</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="currency_format" class="form-label fs-14 text-dark"><?php echo e(__('Currency Showing Format')); ?> <span
                                        class="text-danger">*</span></label>
                                <select class="js-example-basic-single" name="currency_format" id="currency_format">
                                    <option selected disabled><?php echo e(__('-- Select Currency Format --')); ?></option>
                                    <option value="text_symbol" <?php echo e(settings('currency_format') == 'text_symbol' ? 'selected' : ''); ?>><?php echo e(__('Show Currency Text and Symbol Both')); ?></option>
                                    <option value="text" <?php echo e(settings('currency_format') == 'text' ? 'selected' : ''); ?>><?php echo e(__('Show Currency Text Only')); ?></option>
                                    <option value="symbol" <?php echo e(settings('currency_format') == 'symbol' ? 'selected' : ''); ?>><?php echo e(__('Show Currency Symbol Only')); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="default_customer" class="form-label fs-14 text-dark"><?php echo e(__('Default Customer')); ?> <span
                                        class="text-danger">*</span></label>
                                <select class="js-example-basic-single" name="default_customer" id="default_customer">
                                    <option selected disabled><?php echo e(__('-- Select Customer --')); ?></option>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>" <?php echo e(settings('default_customer') == $value->id ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="default_warehouse" class="form-label fs-14 text-dark"><?php echo e(__('Default Warehouse')); ?> <span
                                        class="text-danger">*</span></label>
                                <select class="js-example-basic-single" name="default_warehouse" id="default_warehouse">
                                    <option selected disabled><?php echo e(__('-- Select Warehouse --')); ?></option>
                                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>" <?php echo e(settings('default_warehouse') == $value->id ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="company_address" class="form-label fs-14 text-dark"><?php echo e(__('Company Address')); ?> <span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" name="company_address" id="company_address" rows="3"><?php echo e(settings('company_address')); ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="logo" class="form-label fs-14 text-dark"><?php echo e(__('Logo')); ?></label>
                                <input type="hidden" name="logo" id="logo">
                                <input type="file" class="single-fileupload settings-file-upload logo" data-allow-reorder="true" data-max-file-size="3MB">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="favicon" class="form-label fs-14 text-dark"><?php echo e(__('Favicon')); ?></label>
                                <input type="hidden" name="favicon" id="favicon">
                                <input type="file" class="single-fileupload settings-file-upload favicon" data-allow-reorder="true" data-max-file-size="3MB">
                            </div>
                        </div>
                        <button class="btn btn-primary" type="submit"><?php echo e(__('Submit')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jquery-ui/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/filepond/filepond.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/filepond-plugin-image-preview/filepond-plugin-image-preview.min.js')); ?>"></script>
    <script>
        $(function () {
            "use strict"
            var options = {
                'position': 'top-right'
            }
            var notifier = new AWN(options);
            $('.js-example-basic-single').select2();
            FilePond.registerPlugin(
                FilePondPluginImagePreview,
            );
            const logo = document.querySelector('.logo');
            const pond = FilePond.create(logo, {
                allowImagePreview: true,
                imagePreviewHeight: 170,
                styleLoadIndicatorPosition: 'center bottom',
                styleButtonRemoveItemPosition: 'center bottom',
                maxFiles: 1,
                maxFileSize: '3MB',
                server: {
                    process: {
                        url: '<?php echo e(route('settings.update.file')); ?>',
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        onload: (response) => {
                            $('#logo').val(response);
                        },
                        onerror: (response) => {
                            notifier.alert('Something went wrong');
                        }
                    }
                },
                files: [
                    {
                        source: '<?php echo e(asset('assets/uploads/')); ?>/<?php echo e(settings('logo')); ?>',
                    }
                ]
            });

            const favicon = document.querySelector('.favicon');
            const faviconPond = FilePond.create(favicon, {
                allowImagePreview: true,
                imagePreviewHeight: 170,
                styleLoadIndicatorPosition: 'center bottom',
                styleButtonRemoveItemPosition: 'center bottom',
                maxFiles: 1,
                maxFileSize: '3MB',
                server: {
                    process: {
                        url: '<?php echo e(route('settings.update.file')); ?>',
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        onload: (response) => {
                            $('#favicon').val(response);
                        },
                        onerror: (response) => {
                            notifier.alert('Something went wrong');
                        }
                    }
                },
                files: [
                    {
                        source: '<?php echo e(asset('assets/uploads/')); ?>/<?php echo e(settings('favicon')); ?>',
                    }
                ]
            });

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory\resources\views/setting/index.blade.php ENDPATH**/ ?>