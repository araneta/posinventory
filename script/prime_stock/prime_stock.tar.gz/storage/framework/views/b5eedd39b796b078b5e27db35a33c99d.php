<div class="card custom-card border border-primary">
    <div class="card-body">
        <form action="<?php echo e(request()->url()); ?>" method="get">
            <div class="row">
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="warehouse" class="form-label fs-14 text-dark"><?php echo e(__('Warehouse')); ?> <span
                                class="text-danger">*</span></label>
                        <select class="js-example-basic-single" name="warehouse" id="warehouse">
                            <option selected disabled><?php echo e(__('-- Select Warehouse --')); ?></option>
                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($warehouse->id); ?>" <?php if(request('warehouse') == $warehouse->id): echo 'selected'; endif; ?>><?php echo e($warehouse->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="supplier" class="form-label fs-14 text-dark"><?php echo e(__('Supplier')); ?> <span
                                class="text-danger">*</span></label>
                        <select class="js-example-basic-single" name="supplier" id="supplier">
                            <option selected disabled><?php echo e(__('-- Select Supplier --')); ?></option>
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supplier->id); ?>" <?php if(request('supplier') == $supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="status" class="form-label fs-14 text-dark"><?php echo e(__('Status')); ?> <span
                                class="text-danger">*</span></label>
                        <select class="js-example-basic-single" name="status" id="status">
                            <option selected disabled><?php echo e(__('-- Select Status --')); ?></option>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php if(request('status') == $key): echo 'selected'; endif; ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label for="date" class="form-label fs-14 text-dark"><?php echo e(__('Date Range')); ?> <span
                                class="text-danger">*</span></label>
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-text text-muted"><i class="ri-calendar-line"></i></div>
                                <input type="text" class="form-control" name="date" id="date"
                                       placeholder="Choose date" value="<?php echo e(request('date')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mt-4">
                    <button type="submit" class="btn btn-primary label-btn mt-2 w-40">
                        <i class="ri-filter-2-fill label-btn-icon me-2"></i><?php echo e(__('Filter')); ?>

                    </button>
                    <a href="<?php echo e($resetUrl); ?>" class="btn btn-danger label-btn mt-2 w-40">
                        <i class="ri-refresh-line label-btn-icon me-2"></i><?php echo e(__('Reset')); ?>

                    </a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/purchase/include/__filter.blade.php ENDPATH**/ ?>