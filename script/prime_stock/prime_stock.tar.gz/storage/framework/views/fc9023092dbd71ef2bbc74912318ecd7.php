<footer class="footer mt-auto py-3 bg-white text-center">
    <div class="container">
        <span class="text-muted">
            <?php echo settings('footer_text'); ?>

        </span>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/layouts/partials/__footer.blade.php ENDPATH**/ ?>