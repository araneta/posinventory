<aside class="app-sidebar sticky" id="sidebar">

    <!-- Start::main-sidebar-header -->
    <div class="main-sidebar-header">
        <a href="<?php echo e(route('dashboard')); ?>" class="header-logo">
            <img src="<?php echo e(asset('assets/uploads')); ?>/<?php echo e(settings('logo')); ?>" alt="logo" class="desktop-logo">
            <img src="<?php echo e(asset('assets/uploads')); ?>/<?php echo e(settings('favicon')); ?>" alt="logo" class="toggle-logo">
            <img src="<?php echo e(asset('assets/uploads')); ?>/<?php echo e(settings('logo')); ?>" alt="logo" class="desktop-white">
            <img src="<?php echo e(asset('assets/uploads')); ?>/<?php echo e(settings('favicon')); ?>" alt="logo" class="toggle-white">
        </a>
    </div>
    <!-- End::main-sidebar-header -->

    <!-- Start::main-sidebar -->
    <div class="main-sidebar" id="sidebar-scroll">

        <!-- Start::nav -->
        <nav class="main-menu-container nav nav-pills flex-column sub-open">
            <div class="slide-left" id="slide-left">
                <i class="side-menu__icon ri-dashboard-line"></i>
            </div>
            <ul class="main-menu">
                <!-- Start::slide__category -->
                <li class="slide__category"><span class="category-name"><?php echo e(__('Main')); ?></span></li>
                <!-- End::slide__category -->

                <!-- Start::slide -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard')): ?>
                    <li class="slide <?php echo e(menuActive('dashboard')); ?>">
                        <a href="<?php echo e(route('dashboard')); ?>" class="side-menu__item <?php echo e(menuActive('dashboard')); ?>">
                            <i class="side-menu__icon ri-dashboard-line"></i>
                            <span class="side-menu__label"><?php echo e(__('Dashboard')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(checkPermission(['category', 'brand', 'units', 'variation', 'product', 'print-labels'])): ?>
                    <li class="slide has-sub <?php echo e(submenuActive(['category*', 'brand*', 'units*', 'variation*', 'product*', 'print-labels'])); ?>">
                        <a href="javascript:void(0);" class="side-menu__item">
                            <i class="side-menu__icon ri-product-hunt-fill"></i>
                            <span class="side-menu__label"><?php echo e(__('Product Manage')); ?></span>
                            <i class="fe fe-chevron-right side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-category')): ?>
                                <li class="slide <?php echo e(menuActive('category*')); ?>">
                                    <a href="<?php echo e(route('category.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('category*')); ?>"><?php echo e(__('Category')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-brand')): ?>
                                <li class="slide <?php echo e(menuActive('brand*')); ?>">
                                    <a href="<?php echo e(route('brand.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('brand*')); ?>"><?php echo e(__('Brand')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-unit')): ?>
                                <li class="slide <?php echo e(menuActive('units*')); ?>">
                                    <a href="<?php echo e(route('units.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('units*')); ?>"><?php echo e(__('Units')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-variation')): ?>
                                <li class="slide <?php echo e(menuActive('variation*')); ?>">
                                    <a href="<?php echo e(route('variation.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('variation*')); ?>"><?php echo e(__('Variation')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-product')): ?>
                                <li class="slide <?php echo e(menuActive('product*')); ?>">
                                    <a href="<?php echo e(route('product.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('product*')); ?>"><?php echo e(__('Product')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print-product-labels')): ?>
                                <li class="slide <?php echo e(menuActive('print-labels')); ?>">
                                    <a href="<?php echo e(route('print-labels')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('print-labels')); ?>"><?php echo e(__('Print Labels')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(checkPermission(['purchase', 'purchase-return'])): ?>
                    <li class="slide has-sub <?php echo e(submenuActive(['purchase*', 'purchase-return*'])); ?>">
                        <a href="javascript:void(0);" class="side-menu__item">
                            <i class="side-menu__icon ri-store-fill"></i>
                            <span class="side-menu__label"><?php echo e(__('Purchase')); ?></span>
                            <i class="fe fe-chevron-right side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-purchase')): ?>
                                <li class="slide <?php echo e(menuActive('purchase*')); ?>">
                                    <a href="<?php echo e(route('purchase.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('purchase*')); ?>"><?php echo e(__('All Purchase')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-purchase-return')): ?>
                                <li class="slide <?php echo e(menuActive('purchase-return*')); ?>">
                                    <a href="<?php echo e(route('purchase-return.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('purchase-return*')); ?>"><?php echo e(__('Purchase Return')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(checkPermission(['sale', 'sale-return'])): ?>
                    <li class="slide has-sub <?php echo e(submenuActive(['sale*', 'sale-return*'])); ?>">
                        <a href="javascript:void(0);" class="side-menu__item">
                            <i class="side-menu__icon ri-shopping-cart-fill"></i>
                            <span class="side-menu__label"><?php echo e(__('Sale')); ?></span>
                            <i class="fe fe-chevron-right side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-sale')): ?>
                                <li class="slide <?php echo e(menuActive('sale*')); ?>">
                                    <a href="<?php echo e(route('sale.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('sale*')); ?>"><?php echo e(__('All Sale')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-sale-return')): ?>
                                <li class="slide <?php echo e(menuActive('sale-return*')); ?>">
                                    <a href="<?php echo e(route('sale-return.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('sale-return*')); ?>"><?php echo e(__('Sale Return')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-warehouse')): ?>
                    <?php if(!checkWarehouseAdmin()): ?>
                        <li class="slide <?php echo e(menuActive('warehouse*')); ?>">
                            <a href="<?php echo e(route('warehouse.index')); ?>"
                               class="side-menu__item <?php echo e(menuActive('warehouse*')); ?>">
                                <i class="side-menu__icon ri-home-5-line"></i>
                                <span class="side-menu__label"><?php echo e(__('Warehouse')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-supplier')): ?>
                    <li class="slide <?php echo e(menuActive('supplier*')); ?>">
                        <a href="<?php echo e(route('supplier.index')); ?>" class="side-menu__item <?php echo e(menuActive('supplier*')); ?>">
                            <i class="side-menu__icon ri-user-shared-line"></i>
                            <span class="side-menu__label"><?php echo e(__('Supplier')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-customer')): ?>
                    <li class="slide <?php echo e(menuActive('customer*')); ?>">
                        <a href="<?php echo e(route('customer.index')); ?>" class="side-menu__item <?php echo e(menuActive('customer*')); ?>">
                            <i class="side-menu__icon ri-user-follow-fill"></i>
                            <span class="side-menu__label"><?php echo e(__('Customer')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(checkPermission(['staff', 'role'])): ?>
                    <li class="slide has-sub <?php echo e(submenuActive(['staff*', 'role*'])); ?>">
                        <a href="javascript:void(0);" class="side-menu__item">
                            <i class="side-menu__icon ri-group-2-fill"></i>
                            <span class="side-menu__label"><?php echo e(__('Staff')); ?></span>
                            <i class="fe fe-chevron-right side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-staff')): ?>
                                <li class="slide <?php echo e(menuActive('staff*')); ?>">
                                    <a href="<?php echo e(route('staff.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('staff*')); ?>"><?php echo e(__('All Staff')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-role')): ?>
                                <li class="slide <?php echo e(menuActive('role*')); ?>">
                                    <a href="<?php echo e(route('role.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('role*')); ?>"><?php echo e(__('Role')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(checkPermission(['expense-type', 'expense'])): ?>
                    <li class="slide has-sub <?php echo e(submenuActive(['expense-type*', 'expense*'])); ?>">
                        <a href="javascript:void(0);" class="side-menu__item">
                            <i class="side-menu__icon ri-bank-card-2-line"></i>
                            <span class="side-menu__label"><?php echo e(__('Expense')); ?></span>
                            <i class="fe fe-chevron-right side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-expense-type')): ?>
                                <li class="slide <?php echo e(menuActive('expense-type*')); ?>">
                                    <a href="<?php echo e(route('expense-type.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('expense-type*')); ?>"><?php echo e(__('Expense Type')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-expense')): ?>
                                <li class="slide <?php echo e(menuActive('expense*')); ?>">
                                    <a href="<?php echo e(route('expense.index')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('expense*')); ?>"><?php echo e(__('All Expense')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-adjustment')): ?>
                    <li class="slide <?php echo e(menuActive('adjustment*')); ?>">
                        <a href="<?php echo e(route('adjustment.index')); ?>"
                           class="side-menu__item <?php echo e(menuActive('adjustment*')); ?>">
                            <i class="side-menu__icon ri-scales-line"></i>
                            <span class="side-menu__label"><?php echo e(__('Adjustment')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-transfer')): ?>
                    <li class="slide <?php echo e(menuActive('transfer*')); ?>">
                        <a href="<?php echo e(route('transfer.index')); ?>" class="side-menu__item <?php echo e(menuActive('transfer*')); ?>">
                            <i class="side-menu__icon ri-text-wrap"></i>
                            <span class="side-menu__label"><?php echo e(__('Transfer')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-account')): ?>
                    <li class="slide <?php echo e(menuActive('account*')); ?>">
                        <a href="<?php echo e(route('account.index')); ?>" class="side-menu__item <?php echo e(menuActive('account*')); ?>">
                            <i class="side-menu__icon ri-bank-card-line"></i>
                            <span class="side-menu__label"><?php echo e(__('Account')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-deposit')): ?>
                    <li class="slide <?php echo e(menuActive('deposit*')); ?>">
                        <a href="<?php echo e(route('deposit.index')); ?>" class="side-menu__item <?php echo e(menuActive('deposit*')); ?>">
                            <i class="side-menu__icon ri-wallet-2-line"></i>
                            <span class="side-menu__label"><?php echo e(__('Deposit')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-transaction')): ?>
                    <li class="slide <?php echo e(menuActive('transaction*')); ?>">
                        <a href="<?php echo e(route('transaction.index')); ?>"
                           class="side-menu__item <?php echo e(menuActive('transaction*')); ?>">
                            <i class="side-menu__icon ri-arrow-left-right-line"></i>
                            <span class="side-menu__label"><?php echo e(__('Transaction')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(checkPermission(['report'])): ?>
                    <li class="slide has-sub <?php echo e(submenuActive(['report.profit.loss', 'report.stock', 'report.payment.supplier', 'report.payment.customer', 'report.purchase', 'report.sale', 'report.product', 'report.payment.sale', 'report.payment.purchase', 'report.payment.sale.return', 'report.payment.purchase.return'])); ?>">
                        <a href="javascript:void(0);" class="side-menu__item">
                            <i class="side-menu__icon ri-database-2-line"></i>
                            <span class="side-menu__label"><?php echo e(__('Reports')); ?></span>
                            <i class="fe fe-chevron-right side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profit-loss-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.profit.loss')); ?>">
                                    <a href="<?php echo e(route('report.profit.loss')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.profit.loss')); ?>"><?php echo e(__('Profit Loss Report')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.stock')); ?>">
                                    <a href="<?php echo e(route('report.stock')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.stock')); ?>"><?php echo e(__('Stock Report')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier-payment-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.payment.supplier')); ?>">
                                    <a href="<?php echo e(route('report.payment.supplier')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.payment.supplier')); ?>"><?php echo e(__('Supplier Payment')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer-payment-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.payment.customer')); ?>">
                                    <a href="<?php echo e(route('report.payment.customer')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.payment.customer')); ?>"><?php echo e(__('Customer Payment')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.purchase')); ?>">
                                    <a href="<?php echo e(route('report.purchase')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.purchase')); ?>"><?php echo e(__('Purchase Report')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.sale')); ?>">
                                    <a href="<?php echo e(route('report.sale')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.sale')); ?>"><?php echo e(__('Sale Report')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.product')); ?>">
                                    <a href="<?php echo e(route('report.product')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.product')); ?>"><?php echo e(__('Product Report')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment-sale-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.payment.sale')); ?>">
                                    <a href="<?php echo e(route('report.payment.sale')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.payment.sale')); ?>"><?php echo e(__('Payment Sale')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment-purchase-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.payment.purchase')); ?>">
                                    <a href="<?php echo e(route('report.payment.purchase')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.payment.purchase')); ?>"><?php echo e(__('Payment Purchase')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment-sale-return-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.payment.sale.return')); ?>">
                                    <a href="<?php echo e(route('report.payment.sale.return')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.payment.sale.return')); ?>"><?php echo e(__('Payment Sale Return')); ?></a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment-purchase-return-report')): ?>
                                <li class="slide <?php echo e(menuActive('report.payment.purchase.return')); ?>">
                                    <a href="<?php echo e(route('report.payment.purchase.return')); ?>"
                                       class="side-menu__item <?php echo e(menuActive('report.payment.purchase.return')); ?>"><?php echo e(__('Payment Purchase Return')); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <!-- End::slide -->
                <?php if(checkPermission(['language', 'setting'])): ?>
                    <li class="slide__category"><span class="category-name"><?php echo e(__('Site Settings')); ?></span></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list-language')): ?>
                        <li class="slide <?php echo e(menuActive('language*')); ?>">
                            <a href="<?php echo e(route('language.index')); ?>"
                               class="side-menu__item <?php echo e(menuActive('language*')); ?>">
                                <i class="side-menu__icon ri-global-fill"></i>
                                <span class="side-menu__label"><?php echo e(__('Language Settings')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('system-setting')): ?>
                        <li class="slide <?php echo e(menuActive('settings')); ?>">
                            <a href="<?php echo e(route('settings')); ?>" class="side-menu__item <?php echo e(menuActive('settings')); ?>">
                                <i class="side-menu__icon ri-settings-2-line"></i>
                                <span class="side-menu__label"><?php echo e(__('System Settings')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mail-setting')): ?>
                        <li class="slide <?php echo e(menuActive('settings.email')); ?>">
                            <a href="<?php echo e(route('settings.email')); ?>"
                               class="side-menu__item <?php echo e(menuActive('settings.email')); ?>">
                                <i class="side-menu__icon ri-mail-settings-line"></i>
                                <span class="side-menu__label"><?php echo e(__('Mail Settings')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('email-template')): ?>
                        <li class="slide <?php echo e(menuActive('email-template*')); ?>">
                            <a href="<?php echo e(route('email-template.index')); ?>"
                               class="side-menu__item <?php echo e(menuActive('email-template*')); ?>">
                                <i class="side-menu__icon ri-mail-lock-line"></i>
                                <span class="side-menu__label"><?php echo e(__('Email Template')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <li class="slide__category"><span class="category-name"><?php echo e(__('Extra')); ?></span></li>
                <li class="slide <?php echo e(menuActive('application')); ?>">
                    <a href="<?php echo e(route('application')); ?>"
                       class="side-menu__item <?php echo e(menuActive('application')); ?>">
                        <i class="side-menu__icon ri-apps-fill"></i>
                        <span class="side-menu__label"><?php echo e(__('Application')); ?></span>
                    </a>
                </li>
                <li class="slide <?php echo e(menuActive('server')); ?>">
                    <a href="<?php echo e(route('server')); ?>"
                       class="side-menu__item <?php echo e(menuActive('server')); ?>">
                        <i class="side-menu__icon ri-server-fill"></i>
                        <span class="side-menu__label"><?php echo e(__('Server')); ?></span>
                    </a>
                </li>
                <li class="slide <?php echo e(menuActive('clear')); ?>">
                    <a href="<?php echo e(route('clear')); ?>"
                       class="side-menu__item <?php echo e(menuActive('clear')); ?>">
                        <i class="side-menu__icon ri-copyleft-line"></i>
                        <span class="side-menu__label"><?php echo e(__('Cache')); ?></span>
                    </a>
                </li>
            </ul>
            <div class="slide-right" id="slide-right">
                <i class="side-menu__icon ri-dashboard-line"></i>
            </div>
        </nav>
        <!-- End::nav -->

    </div>
    <!-- End::main-sidebar -->

</aside>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/layouts/partials/__sidebar.blade.php ENDPATH**/ ?>