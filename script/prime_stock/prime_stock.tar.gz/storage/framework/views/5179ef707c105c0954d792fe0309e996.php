<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="ltr" data-nav-layout="vertical"
      data-theme-mode="light" data-header-styles="light" data-menu-styles="dark" data-toggled="close">

<?php echo $__env->make('layouts.partials.__head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

<!-- Loader -->
<div id="loader">
    <img src="<?php echo e(asset('assets/images/loader.svg')); ?>" alt="">
</div>
<!-- Loader -->

<div class="page">
    <!-- app-header -->
    <?php echo $__env->make('layouts.partials.__header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /app-header -->

    <!--End modal -->
    <!-- Start::app-sidebar -->
    <?php echo $__env->make('layouts.partials.__sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End::app-sidebar -->

    <!-- Start::app-content -->
    <div class="main-content app-content">
        <div class="container-fluid">

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
    <!-- End::app-content -->

    <!-- Footer Start -->
    <?php echo $__env->make('layouts.partials.__footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer End -->

</div>



<div class="floatingButtonWrap">
    <div class="floatingButtonInner">
        <a href="#" class="floatingButton">
            <i class="fa fa-plus icon-default"></i>
        </a>
        <ul class="floatingMenu">
            <li>
                <a href="<?php echo e(route('supplier.create')); ?>"><?php echo e(__('Add Supplier')); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('customer.create')); ?>"><?php echo e(__('Add Customer')); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('purchase.create')); ?>"><?php echo e(__('Add Purchase')); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('sale.create')); ?>"><?php echo e(__('Add Sale')); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('report.stock')); ?>"><?php echo e(__('Stock Report')); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('report.profit.loss')); ?>"><?php echo e(__('Profit Loss Report')); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('report.sale')); ?>"><?php echo e(__('Sale Report')); ?></a>
            </li>
            <li>
                <a href="<?php echo e(route('report.purchase')); ?>"><?php echo e(__('Purchase Report')); ?></a>
            </li>
        </ul>
    </div>
</div>

<!-- Scroll To Top -->
<div class="scrollToTop">
    <span class="arrow"><i class="las la-angle-double-up"></i></span>
</div>
<div id="responsive-overlay"></div>
<!-- Scroll To Top -->

<?php echo $__env->make('layouts.partials.__script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\inventory\resources\views/layouts/app.blade.php ENDPATH**/ ?>