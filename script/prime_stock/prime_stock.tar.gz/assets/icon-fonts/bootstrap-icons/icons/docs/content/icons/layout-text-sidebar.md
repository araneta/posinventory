---
title: Layout text sidebar
categories:
  - Layout
tags:
  - layout
  - columns
---
