---
title: Sliders2
categories:
  - Graphics
tags:
  - equalizer
  - settings
  - preferences
  - dials
---
