---
title: Star fill
categories:
  - Shapes
tags:
  - shape
  - like
  - favorite
---
