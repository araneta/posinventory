---
title: Tablet landscape fill
categories:
  - Devices
tags:
  - mobile
---
