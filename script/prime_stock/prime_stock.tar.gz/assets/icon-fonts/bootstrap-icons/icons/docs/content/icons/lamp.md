---
title: Lamp
categories:
  - Real world
tags:
  - light
  - lamp
---
