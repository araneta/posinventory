---
title: Window split
categories:
  - Apps
tags:
  - application
  - desktop
  - app
---
