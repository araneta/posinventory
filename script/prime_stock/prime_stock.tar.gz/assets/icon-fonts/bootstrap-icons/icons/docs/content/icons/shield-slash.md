---
title: Shield slash
categories:
  - Security
tags:
  - shield
  - badge
---
