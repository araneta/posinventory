---
title: View stacked
categories:
  - UI and keyboard
tags:
  - view
  - rearrange
---
