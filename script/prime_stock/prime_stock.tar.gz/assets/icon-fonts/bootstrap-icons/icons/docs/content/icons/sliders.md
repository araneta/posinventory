---
title: Sliders
categories:
  - Graphics
tags:
  - equalizer
  - settings
  - preferences
  - dials
---
