---
title: Textarea t
categories:
  - Graphics
tags:
  - text
  - insert
  - bounding-box
---
