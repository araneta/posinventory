---
title: Window fullscreen
categories:
  - Apps
tags:
  - application
  - desktop
  - app
---
