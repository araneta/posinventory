---
title: Infinity
categories:
  - Typography
tags:
  - math
  - infinite
---
