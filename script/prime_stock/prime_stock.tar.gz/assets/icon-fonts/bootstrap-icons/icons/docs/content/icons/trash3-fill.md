---
title: Trash3 fill
categories:
  - UI and keyboard
tags:
  - trash-can
  - garbage
  - delete
---
