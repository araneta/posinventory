---
title: Wifi
categories:
  - Communications
tags:
  - internet
  - network
  - wireless
---
