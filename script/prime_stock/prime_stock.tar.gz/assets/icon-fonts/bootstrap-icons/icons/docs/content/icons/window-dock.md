---
title: Window dock
categories:
  - Apps
tags:
  - application
  - desktop
  - os
---
