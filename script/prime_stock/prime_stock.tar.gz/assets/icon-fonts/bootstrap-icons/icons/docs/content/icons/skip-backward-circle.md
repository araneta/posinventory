---
title: Skip backward circle
categories:
  - Media
tags:
  - audio
  - video
  - av
---
