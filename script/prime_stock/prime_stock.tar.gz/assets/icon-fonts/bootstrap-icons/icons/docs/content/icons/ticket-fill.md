---
title: Ticket fill
categories:
  - Real World
tags:
  - tickets
  - admission
---
