---
title: Megaphone fill
categories:
  - Real world
tags:
  - loudspeaker
  - announcement
---
