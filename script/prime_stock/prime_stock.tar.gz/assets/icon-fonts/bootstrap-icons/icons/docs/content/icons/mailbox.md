---
title: Mailbox
categories:
  - Real world
tags:
  - post
  - postal
  - postbox
  - letterbox
---
