---
title: List task
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
  - todos
  - task
---
