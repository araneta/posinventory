---
title: Type strikethrough
categories:
  - Typography
tags:
  - text
  - type
---
