---
title: Type H2
categories:
  - Typography
tags:
  - text
  - type
  - heading
---
