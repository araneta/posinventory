---
title: Lightning fill
categories:
  - Weather
tags:
  - storm
  - thunder
  - bolt
---
