---
title: Smartwatch
categories:
  - Devices
tags:
  - watch
  - wearables
---
