---
title: Symmetry vertical
categories:
  - Graphics
tags:
  - align
  - orientation
  - mirror
---
