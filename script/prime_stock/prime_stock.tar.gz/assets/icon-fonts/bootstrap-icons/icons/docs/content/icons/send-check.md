---
title: Send check
categories:
  - Communications
tags:
  - message
  - sending
  - sent
---
