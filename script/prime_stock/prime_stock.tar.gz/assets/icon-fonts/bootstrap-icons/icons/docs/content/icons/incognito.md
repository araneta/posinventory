---
title: Incognito
categories:
  - Miscellaneous
tags:
  - private
  - investigator
  - secret
---
