---
title: Tablet fill
categories:
  - Devices
tags:
  - mobile
---
