---
title: Type underline
categories:
  - Typography
tags:
  - text
  - type
---
