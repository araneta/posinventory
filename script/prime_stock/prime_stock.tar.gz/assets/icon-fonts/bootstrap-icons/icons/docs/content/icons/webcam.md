---
title: Webcam
categories:
  - Devices
tags:
  - camera
  - video
---
