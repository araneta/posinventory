---
title: Speaker fill
categories:
  - Devices
tags:
  - audio
  - sound
---
