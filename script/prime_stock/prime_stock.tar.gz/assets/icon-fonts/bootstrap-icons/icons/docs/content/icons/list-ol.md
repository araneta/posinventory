---
title: List OL
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
  - ordered-list
  - numbered-list
  - numbered
---
