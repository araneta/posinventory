---
title: Thermometer half
categories:
  - Weather
tags:
  - temperature
  - weather
---
