---
title: Zoom in
categories:
  - Graphics
tags:
  - magnify
  - scale
---
