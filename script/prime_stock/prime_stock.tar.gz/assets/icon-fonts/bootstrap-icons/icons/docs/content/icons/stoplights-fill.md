---
title: Stoplights fill
categories:
  - Real world
tags:
  - traffic
  - lights
  - intersection
---
