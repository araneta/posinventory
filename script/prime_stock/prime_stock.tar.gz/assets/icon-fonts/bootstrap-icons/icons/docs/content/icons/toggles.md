---
title: Toggles
categories:
  - Controls
tags:
  - toggle
  - switch
  - checkbox
---
