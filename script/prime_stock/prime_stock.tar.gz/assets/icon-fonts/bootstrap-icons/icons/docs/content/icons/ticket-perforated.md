---
title: Ticket perforated
categories:
  - Real World
tags:
  - tickets
  - admission
---
