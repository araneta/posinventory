---
title: Type bold
categories:
  - Typography
tags:
  - text
  - type
---
