---
title: Shield slash fill
categories:
  - Security
tags:
  - shield
  - badge
---
