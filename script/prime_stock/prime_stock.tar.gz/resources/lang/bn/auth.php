<?php

return array (
  'failed' => '',
  'password' => '',
  'throttle' => '',
);
